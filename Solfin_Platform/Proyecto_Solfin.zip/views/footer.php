<!-- 
<div class="alert alert-info">
    <strong>&copy 2015</strong> CRUD File
</div> 
-->

</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<!-- Latest compiled and minified JavaScript -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

<script>
	$('#selectID').val('<?php echo $edit_row['docType']; ?>');
</script>

</body>
</html>