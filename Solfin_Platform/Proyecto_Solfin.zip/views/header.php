<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no" />
<title>Plataforma de Archivos - SOLFIN </title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
</head>

<body>

<div class="navbar navbar-inverse navbar-static-top" role="navigation">
    <div class="container">
 
        <div class="navbar-header">
            <a class="navbar-brand" href="/" title='CRUD File' >SOLFIN - Casa de Bolsa - Bienvenido <?php echo  $_SESSION['username'];?> </a>
            <a href=logout.php><button type="button" class="btn btn-success"> Cerrar Sesion</button></a>
        </div>
 
    </div>
</div>